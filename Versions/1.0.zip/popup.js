document.getElementById('proxy1').addEventListener('click', function() {
  setAndApplyProxy("proxy1", "70.35.213.226", "4153");
});

document.getElementById('proxy2').addEventListener('click', function() {
  setAndApplyProxy("proxy2", "148.77.34.200", "54321");
});

document.getElementById('proxy3').addEventListener('click', function() {
  setAndApplyProxy("proxy3", "38.113.171.88", "57775");
});

document.getElementById('disableProxy').addEventListener('click', function() {
  disableProxy();
});

document.getElementById('applyButton').addEventListener('click', function() {
  applySelectedProxy();
});

function setAndApplyProxy(selectedProxy, host, port) {
  chrome.storage.local.set({ selectedProxy: selectedProxy }, function() {
    console.log('Выбран прокси:', selectedProxy);
    applyProxySettings(host, port);
  });
}

function applySelectedProxy() {
  chrome.storage.local.get('selectedProxy', function(data) {
    const selectedProxy = data.selectedProxy;

    if (selectedProxy) {
      if (selectedProxy === "proxy1") {
        applyProxySettings("70.35.213.226", "4153");
      } else if (selectedProxy === "proxy2") {
        applyProxySettings("148.77.34.200", "54321");
      } else if (selectedProxy === "proxy3") {
        applyProxySettings("38.113.171.88", "57775");
      }
    } else {
      console.log('Не выбран прокси. Примените прокси сначала.');
    }
  });
}

function disableProxy() {
  chrome.proxy.settings.clear({ scope: 'regular' }, function() {
    console.log('Прокси отключен');
  });
}

function applyProxySettings(host, port) {
  chrome.proxy.settings.set({
    value: {
      mode: "fixed_servers",
      rules: {
        singleProxy: {
          scheme: "socks4",
          host: host,
          port: parseInt(port)
        }
      }
    },
    scope: "regular"
  }, function() {
    console.log('Прокси применен');
  });
}
